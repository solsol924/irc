RealSense YOLO integration
==========================

Target repo:
~/irc

Current architecture preserved:
- C920 yolo_detector.py stays unchanged.
- New realsense_yolo_detector.py handles RealSense goal/backboard/ball.
- ball_vision_fusion.py keeps webcam fusion and BallResult output.
- Old HSV hoop_vision.py remains available as fallback but is OFF by default.

Expected RealSense engine path:
  /home/rnd/realsense_goal_backboard_ball_best.engine

If your engine path is different, change:
  ~/irc/src/vision/config/settings.ini
  [realsense_yolo] model = ...

Apply:
  cd <this extracted folder>
  python3 apply_realsense_yolo_integration.py

Build:
  cd ~/irc
  colcon build --packages-select vision robot_bringup
  source ~/irc/install/setup.bash

Run:
  ros2 launch robot_bringup vision_stack.launch.py

Check:
  ros2 topic list | grep -E "realsense_yolo|hoop|ball|camera"
  ros2 topic echo /realsense_yolo/ball_state
  ros2 topic echo /hoop/vision_state
  sudo tegrastats

Debug image:
  ros2 run rqt_image_view rqt_image_view /vision/realsense_debug_image

Fallback to old HSV hoop:
  ros2 launch robot_bringup vision_stack.launch.py start_realsense_yolo:=false start_hoop:=true

Backups:
The patcher creates *.before_realsense_yolo files before modifying current code.
