#!/usr/bin/env python3
"""
Patch ~/irc for RealSense YOLO integration.
Creates *.before_realsense_yolo backups before modifying files.
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

REPO = Path.home() / "irc"
VISION = REPO / "src" / "vision"
SCRIPTS = VISION / "scripts"
CONFIG = VISION / "config"
LAUNCH_DIR = REPO / "src" / "robot_bringup" / "launch"
BUNDLE = Path(__file__).resolve().parent


def backup(path: Path) -> None:
    dst = path.with_name(path.name + ".before_realsense_yolo")
    if not dst.exists():
        shutil.copy2(path, dst)
        print(f"[backup] {dst}")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        print(f"[skip] {label}")
        return text
    if old not in text:
        raise RuntimeError(
            f"Anchor not found: {label}\n"
            "Local code may differ from the expected GitHub main version."
        )
    print(f"[patch] {label}")
    return text.replace(old, new, 1)


def install_detector() -> None:
    src = BUNDLE / "realsense_yolo_detector.py"
    dst = SCRIPTS / "realsense_yolo_detector.py"
    if dst.exists():
        backup(dst)
    shutil.copy2(src, dst)
    dst.chmod(0o755)
    print(f"[ok] {dst}")


def patch_ball_fusion() -> None:
    path = SCRIPTS / "ball_vision_fusion.py"
    backup(path)
    text = path.read_text(encoding="utf-8")

    old = '        self.declare_parameter("webcam_state_topic", "/line_tracker/state")'
    new = """        self.declare_parameter("use_realsense_yolo", False)
        self.declare_parameter(
            "realsense_yolo_state_topic",
            "/realsense_yolo/ball_state",
        )
        self.declare_parameter("webcam_state_topic", "/line_tracker/state")"""
    text = replace_once(text, old, new, "ball fusion parameters")

    old = """        # =========================================================
        # ROS I/O
        # =========================================================
        # RealSense 구독과 synchronizer는 프로세스 수명 동안 유지한다."""
    new = """        # =========================================================
        # ROS I/O
        # =========================================================
        self.use_realsense_yolo = bool(
            self.get_parameter("use_realsense_yolo").value
        )
        self.realsense_yolo_state_topic = str(
            self.get_parameter("realsense_yolo_state_topic").value
        )

        # RealSense 구독과 synchronizer는 프로세스 수명 동안 유지한다."""
    text = replace_once(text, old, new, "ball fusion ROS config")

    old = """        self.ball_status_publisher = BallStatusPublisher(
            self,
            topic_name=self.ball_result_topic,
        )"""
    new = """        self.sub_realsense_yolo_state = None
        if self.use_realsense_yolo:
            self.sub_realsense_yolo_state = self.create_subscription(
                String,
                self.realsense_yolo_state_topic,
                self.cb_realsense_yolo_state,
                10,
            )
            self.get_logger().info(
                "RealSense ball source: YOLO "
                f"{self.realsense_yolo_state_topic}"
            )

        self.ball_status_publisher = BallStatusPublisher(
            self,
            topic_name=self.ball_result_topic,
        )"""
    text = replace_once(text, old, new, "ball fusion YOLO subscription")

    old = """        self._start_ball_image_subscriptions()

        self.get_logger().info("BallVisionFusionNode started.")"""
    new = """        if self.use_realsense_yolo:
            self.get_logger().info(
                "Legacy RealSense HSV ball processing disabled."
            )
        else:
            self._start_ball_image_subscriptions()

        self.get_logger().info("BallVisionFusionNode started.")"""
    text = replace_once(text, old, new, "disable legacy HSV ball detector")

    old = """    # =============================================================
    # 카메라 내부 파라미터
    # =============================================================
    def cb_camera_info(self, msg: CameraInfo) -> None:"""
    new = """    def cb_realsense_yolo_state(self, msg: String) -> None:
        # Feed RealSense YOLO output into the existing fusion/publisher logic.
        if not getattr(self, "ball_detection_active", True):
            return

        now = time.monotonic()
        try:
            payload = json.loads(msg.data)
        except (json.JSONDecodeError, TypeError):
            self.get_logger().warn(
                "Failed to parse /realsense_yolo/ball_state JSON"
            )
            return

        if not isinstance(payload, dict):
            return

        state = self._empty_realsense_state()
        state.update(payload)

        detected = bool(state.get("realsense_ball_detected", False))
        if detected:
            try:
                distance_cm = float(state.get("realsense_ball_distance_cm"))
                angle_deg = float(state.get("realsense_ball_angle_error"))
            except (TypeError, ValueError):
                detected = False
            else:
                if (
                    not math.isfinite(distance_cm)
                    or distance_cm <= 0.0
                    or not math.isfinite(angle_deg)
                ):
                    detected = False

        if not detected:
            diagnostic = state.get("realsense_diagnostic")
            state = self._empty_realsense_state()
            if isinstance(diagnostic, dict):
                state["realsense_diagnostic"] = diagnostic
            state["realsense_ball_detected"] = False

        self.latest_realsense = state
        self.latest_realsense_time = now

    # =============================================================
    # 카메라 내부 파라미터
    # =============================================================
    def cb_camera_info(self, msg: CameraInfo) -> None:"""
    text = replace_once(text, old, new, "ball fusion YOLO callback")

    path.write_text(text, encoding="utf-8")
    print(f"[ok] {path}")


def patch_cmake() -> None:
    path = VISION / "CMakeLists.txt"
    backup(path)
    text = path.read_text(encoding="utf-8")

    old = """install(PROGRAMS
  scripts/yolo_detector.py
  scripts/ball_vision_fusion.py"""
    new = """install(PROGRAMS
  scripts/yolo_detector.py
  scripts/realsense_yolo_detector.py
  scripts/ball_vision_fusion.py"""
    text = replace_once(text, old, new, "CMake install new detector")
    path.write_text(text, encoding="utf-8")
    print(f"[ok] {path}")


def patch_settings() -> None:
    path = CONFIG / "settings.ini"
    backup(path)
    text = path.read_text(encoding="utf-8")

    if "[realsense_yolo]" in text:
        print("[skip] settings.ini already has [realsense_yolo]")
        return

    section = """

[realsense_yolo]
model = /home/rnd/realsense_goal_backboard_ball_best.engine
conf = 0.20
goal_conf = 0.30
backboard_conf = 0.30
ball_conf = 0.25
imgsz = 640
device = 0
max_fps = 10

goal_class = goal
backboard_class = backboard
ball_class = ball

depth_scale = 0.001
depth_min_m = 0.08
depth_max_m = 3.0
depth_inner_ratio_ball = 0.45
depth_inner_ratio_hoop = 0.30
min_valid_depth_pixels = 5

publish_debug_image = true
print_every_n_frames = 10
"""
    path.write_text(text.rstrip() + section + "\n", encoding="utf-8")
    print(f"[ok] {path}")


def patch_launch() -> None:
    path = LAUNCH_DIR / "vision_stack.launch.py"
    backup(path)
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        """    start_yolo = LaunchConfiguration("start_yolo")
    start_ball = LaunchConfiguration("start_ball")""",
        """    start_yolo = LaunchConfiguration("start_yolo")
    start_realsense_yolo = LaunchConfiguration("start_realsense_yolo")
    start_ball = LaunchConfiguration("start_ball")""",
        "launch config variable",
    )

    text = replace_once(
        text,
        """    yolo_script = PathJoinSubstitution([scripts_dir, "yolo_detector.py"])
    ball_script = PathJoinSubstitution([scripts_dir, "ball_vision_fusion.py"])""",
        """    yolo_script = PathJoinSubstitution([scripts_dir, "yolo_detector.py"])
    realsense_yolo_script = PathJoinSubstitution(
        [scripts_dir, "realsense_yolo_detector.py"]
    )
    ball_script = PathJoinSubstitution([scripts_dir, "ball_vision_fusion.py"])""",
        "launch detector path",
    )

    text = replace_once(
        text,
        """        DeclareLaunchArgument("start_yolo", default_value="true"),
        DeclareLaunchArgument("start_ball", default_value="true"),""",
        """        DeclareLaunchArgument("start_yolo", default_value="true"),
        DeclareLaunchArgument("start_realsense_yolo", default_value="true"),
        DeclareLaunchArgument("start_ball", default_value="true"),""",
        "launch argument",
    )

    old = '        DeclareLaunchArgument("start_hoop", default_value="true"),'
    new = '        DeclareLaunchArgument("start_hoop", default_value="false"),'
    if new not in text:
        if old not in text:
            raise RuntimeError("Anchor not found: legacy start_hoop")
        text = text.replace(old, new, 1)
        print("[patch] legacy hoop default false")
    else:
        print("[skip] legacy hoop already default false")

    text = replace_once(
        text,
        """    ball_process = ExecuteProcess(
        name="ball_vision_fusion_process",""",
        """    realsense_yolo_process = ExecuteProcess(
        name="realsense_yolo_process",
        cmd=[sys.executable, realsense_yolo_script, settings_ini],
        cwd=scripts_dir,
        output="screen",
        emulate_tty=True,
        respawn=True,
        respawn_delay=2.0,
        condition=IfCondition(start_realsense_yolo),
        additional_env={"PYTHONUNBUFFERED": "1"},
    )

    ball_process = ExecuteProcess(
        name="ball_vision_fusion_process",""",
        "launch RS YOLO process",
    )

    text = replace_once(
        text,
        """        cmd=[sys.executable, ball_script],
        cwd=scripts_dir,""",
        """        cmd=[
            sys.executable,
            ball_script,
            "--ros-args",
            "-p",
            "use_realsense_yolo:=true",
        ],
        cwd=scripts_dir,""",
        "launch ball fusion YOLO mode",
    )

    text = replace_once(
        text,
        """    delayed_vision = TimerAction(
        period=2.0,""",
        """    # Stagger TensorRT engine initialization to reduce peak memory.
    delayed_realsense_yolo = TimerAction(
        period=4.0,
        actions=[realsense_yolo_process],
    )

    delayed_vision = TimerAction(
        period=2.0,""",
        "launch delayed RS YOLO",
    )

    text = replace_once(
        text,
        """            yolo_process,
            delayed_vision,""",
        """            yolo_process,
            delayed_realsense_yolo,
            delayed_vision,""",
        "launch description",
    )

    path.write_text(text, encoding="utf-8")
    print(f"[ok] {path}")


def main() -> None:
    required = [
        SCRIPTS / "ball_vision_fusion.py",
        VISION / "CMakeLists.txt",
        CONFIG / "settings.ini",
        LAUNCH_DIR / "vision_stack.launch.py",
    ]
    missing = [p for p in required if not p.exists()]
    if missing:
        print("[ERROR] Expected ~/irc files are missing:")
        for p in missing:
            print(" -", p)
        sys.exit(1)

    install_detector()
    patch_ball_fusion()
    patch_cmake()
    patch_settings()
    patch_launch()

    print()
    print("PATCH COMPLETE")
    print("1) Check engine path in ~/irc/src/vision/config/settings.ini")
    print("2) cd ~/irc && colcon build --packages-select vision robot_bringup")
    print("3) source ~/irc/install/setup.bash")
    print("4) ros2 launch robot_bringup vision_stack.launch.py")
    print()
    print("Fallback legacy hoop:")
    print("ros2 launch robot_bringup vision_stack.launch.py "
          "start_realsense_yolo:=false start_hoop:=true")


if __name__ == "__main__":
    main()
